package com.service.planservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanserviceApplication.class, args);
	}

}
