package com.service.notification.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.service.notification.service.EmailService;



@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/user/registered/{userId}")
    public void notifyUserRegistration(@PathVariable Long userId) {
        emailService.notifyUserRegistration(userId);
    }

    @PostMapping("/user/login/{userId}")
    public void notifyUserLogin(@PathVariable Long userId) {
        emailService.notifyUserLogin(userId);
    }

    @PostMapping("/user/deleted/{userId}")
    public void notifyUserDeletion(@PathVariable Long userId) {
        emailService.notifyUserDeletion(userId);
    }

    @PostMapping("/payment/success/{paymentId}")
    public void notifyPaymentSuccess(@PathVariable Long paymentId) {
        emailService.notifyPaymentSuccess(paymentId);
    }

    @PostMapping("/payment/failure/{paymentId}")
    public void notifyPaymentFailure(@PathVariable Long paymentId) {
        emailService.notifyPaymentFailure(paymentId);
    }
}

