package com.subscriptionmanagementsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.subscriptionmanagementsystem.service.EmailService;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/user/registered")
    public void notifyUserRegistration(@RequestParam String email) {
        emailService.notifyUserRegistration(email);
    }

    @PostMapping("/user/login")
    public void notifyUserLogin(@RequestParam String email) {
        emailService.notifyUserLogin(email);
    }

    @PostMapping("/user/deleted")
    public void notifyUserDeletion(@RequestParam String email) {
        emailService.notifyUserDeletion(email);
    }

    @PostMapping("/payment/success")
    public void notifyPaymentSuccess(@RequestParam String email) {
        emailService.notifyPaymentSuccess(email);
    }

    @PostMapping("/payment/failure")
    public void notifyPaymentFailure(@RequestParam String email) {
        emailService.notifyPaymentFailure(email);
    }
}
