package com.verizon.usermanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.usermanagement.entity.OrderTable;
import com.verizon.usermanagement.repository.OrderRepository;

@Service
public class OrderService {
    
    @Autowired
    private OrderRepository orderRepository;

    public OrderTable createOrder(OrderTable order) {
        return orderRepository.save(order);
    }

    public OrderTable updateOrder(Long orderId, OrderTable orderDetails) {
        Optional<OrderTable> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isPresent()) {
            OrderTable order = optionalOrder.get();
            order.setUserId(orderDetails.getUserId());
            order.setPlan(orderDetails.getPlan());
            order.setStartDate(orderDetails.getStartDate());
            order.setEndDate(orderDetails.getEndDate());
            order.setActive(orderDetails.getActive());
            return orderRepository.save(order);
        }
        return null; // or throw an exception
    }

    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
    }

    public OrderTable getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }

    public List<OrderTable> getAllOrders() {
        return orderRepository.findAll();
    }

    public List<OrderTable> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public List<OrderTable> getActiveOrders(Boolean active) {
        return orderRepository.findByActive(active);
    }
    
}
