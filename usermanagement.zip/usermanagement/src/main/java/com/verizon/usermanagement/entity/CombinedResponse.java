package com.verizon.usermanagement.entity;

import org.apache.catalina.User;

public class CombinedResponse {

    private User user;
    private Plan plan;
    private OrderTable orderTable;

    // Constructor
    public CombinedResponse(User user, Plan plan, OrderTable orderTable) {
        this.user = user;
        this.plan = plan;
        this.orderTable = orderTable;
    }

    // Getters and Setters
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Plan getPlan() { return plan; }
    public void setPlan(Plan plan) { this.plan = plan; }

    public OrderTable getOrderTable() { return orderTable; }
    public void setOrderTable(OrderTable orderTable) { this.orderTable = orderTable; }
}

