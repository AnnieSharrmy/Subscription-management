package com.order.orderservice.model;

public class OrderResponse {
    private Order_Table order;
    private String message;

    public OrderResponse(Order_Table order, String message) {
        this.order = order;
        this.message = message;
    }

    // Getters and Setters

    public Order_Table getOrder() {
        return order;
    }

    public void setOrder(Order_Table order) {
        this.order = order;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
