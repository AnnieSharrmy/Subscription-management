package com.order.orderservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.orderservice.model.OrderResponse;
import com.order.orderservice.model.Order_Table;
import com.order.orderservice.repository.OrderRepository;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Data
@Setter
@EqualsAndHashCode
@Getter
@AllArgsConstructor
@NoArgsConstructor
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;

    @PostMapping
    public ResponseEntity<Order_Table> createOrder(@RequestBody Order_Table order) {
        Order_Table savedOrder = orderRepository.save(order);
        return ResponseEntity.ok(savedOrder);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable Long id) {
        Optional<Order_Table> order = orderRepository.findById(id);
        if (order.isPresent() == true) {
            return ResponseEntity.ok(new OrderResponse(order.get(), "Order is not successful"));
        } else {
            return ResponseEntity.status(404).body(new OrderResponse(null, "Order with ID " + id + " is  successfull"));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order_Table> updateOrder(@PathVariable Long id, @RequestBody Order_Table order) {
        if (!orderRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        order.setId(id);
        Order_Table updatedOrder = orderRepository.save(order);
        return ResponseEntity.ok(updatedOrder);
    }

    @DeleteMapping("/{id}")
public ResponseEntity<String> deleteOrder(@PathVariable Long id) {
    if (!orderRepository.existsById(id)) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Order with ID " + id + " not found.");
    }
    orderRepository.deleteById(id);
    return ResponseEntity.ok("Order with ID " + id + " has been successfully deleted.");
}
    
}
