package com.service.orderservice.service;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.service.orderservice.client.PaymentClient;
import com.service.orderservice.entity.Orders;
import com.service.orderservice.entity.OrderRequest;
import com.service.orderservice.repository.OrderRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private PaymentClient paymentClient;

    @Transactional
    public boolean createOrder(OrderRequest orderRequest) {
        try {
            // Define the DateTimeFormatter
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    
            // Convert String to LocalDateTime
            LocalDateTime startDate = LocalDateTime.parse(orderRequest.getStartDate(), formatter);
            LocalDateTime endDate = LocalDateTime.parse(orderRequest.getEndDate(), formatter);
    
            // Create the order
            Orders order = new Orders();
            order.setUserId(orderRequest.getUserId());
            order.setPlan(orderRequest.getPlan());
            order.setStartDate(startDate);
            order.setEndDate(endDate);
            order.setActive(true);
    
            Orders savedOrder = orderRepository.save(order);
    
            // Check if order is successfully created
            if (savedOrder != null) {
                // Forward to payment service
                String response = paymentClient.processPayment(savedOrder.getOrderId());
                if (response.equals("Payment processed successfully.")) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            // Handle exceptions and database errors
            e.printStackTrace();
            return false;
        }
    }
}