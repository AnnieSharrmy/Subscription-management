package com.subscriptionmanagementsystem.notification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.subscriptionmanagementsystem.notification.dto.PaymentResponse;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private PaymentClient paymentClient;

    public void sendEmail(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        try {
            javaMailSender.send(message);
        } catch (Exception e) {
            // Log or handle email sending failure
            e.printStackTrace();
        }
    }

    public void notifyPaymentSuccess(Long paymentId) {
        PaymentResponse payment = paymentClient.getPaymentDetails(paymentId);
        sendEmail(payment.getEmail(), "Payment Success", "Your payment was successful.");
    }

    public void notifyPaymentFailure(Long paymentId) {
        PaymentResponse payment = paymentClient.getPaymentDetails(paymentId);
        sendEmail(payment.getEmail(), "Payment Failure", "Your payment failed. Please try again.");
    }
}
