package com.verizon.usermanagement.repository; 

import org.springframework.data.jpa.repository.JpaRepository;

import com.verizon.usermanagement.entity.Plan;

public interface PlanRepository extends  JpaRepository<Plan,Long>{

}
