package com.service.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "users-service")  // The name of the Users microservice
public interface UsersClient {

    @GetMapping("/api/users/{userId}/email")
    String getUserEmailById(@PathVariable("userId") Long userId);
}
