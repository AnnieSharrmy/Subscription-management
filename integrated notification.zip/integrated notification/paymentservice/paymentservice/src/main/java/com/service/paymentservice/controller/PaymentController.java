package com.service.paymentservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.service.paymentservice.entity.Payment;
import com.service.paymentservice.service.PaymentService;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;
    
    @PostMapping("/process")
    public ResponseEntity<String> processPayment(@RequestParam Long orderId,@RequestParam String email) {
        Payment payment = paymentService.processPayment(orderId,email);
            return ResponseEntity.ok("Payment processed successfully.");
        }
    

    @GetMapping("/{id}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long id) {
        Payment payment = paymentService.getPaymentById(id);
      
            return ResponseEntity.ok(payment);
    
    }
}
