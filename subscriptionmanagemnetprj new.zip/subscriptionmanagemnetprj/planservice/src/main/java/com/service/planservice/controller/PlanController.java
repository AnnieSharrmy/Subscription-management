package com.service.planservice.controller;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.service.planservice.entity.Plan;
import com.service.planservice.exception.PlanNotFoundException;
import com.service.planservice.service.PlanService;

import java.util.List;

@RestController
@RequestMapping("/plans")
public class PlanController {

    @Autowired
    private PlanService planService;

    @GetMapping("/{id}")
    public ResponseEntity<Object> getPlanById(@PathVariable("id") Long id) {
        try {
            Plan plan = planService.getPlanById(id);
            return ResponseEntity.ok(plan);
        } catch (PlanNotFoundException e) {
            return ResponseEntity.status(HttpStatus.SC_NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/cost/{price}")
    public ResponseEntity<List<Plan>> getPlansByCost(@PathVariable Double price) {
        List<Plan> plans = planService.getPlansByCost(price);
        if (plans != null && !plans.isEmpty()) {
            return ResponseEntity.ok(plans);
        } else {
            return ResponseEntity.noContent().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Plan>> getAllPlans() {
        List<Plan> plans = planService.getAllPlans();
        return ResponseEntity.ok(plans);
    } 
}