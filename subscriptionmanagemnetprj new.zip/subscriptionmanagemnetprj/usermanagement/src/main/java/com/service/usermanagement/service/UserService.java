package com.service.usermanagement.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.service.usermanagement.entity.Users;
import com.service.usermanagement.exception.UserNotFoundException;
import com.service.usermanagement.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public Users registerUser(Users user) {
        user.setCreatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }

    public Users loginUser(String email, String passwordHash) {
        Users user = userRepository.findByEmail(email);
        if (user != null && user.getPasswordHash().equals(passwordHash)) {
            return user;
        } else {
            return null; // Return null if credentials are invalid
        }
    }

    public Users getUserById(Long id) {
        Optional<Users> userOptional = userRepository.findById(id);

        if (userOptional.isPresent()) {
            return userOptional.get();
        } else {
            throw new UserNotFoundException("User not found with ID: " + id);
        }
    }
}
