package com.subscriptionmanagementsystem.notification.service;

import com.subscriptionmanagementsystem.notification.dto.PaymentResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PaymentClient {

    @Autowired
    private RestTemplate restTemplate;

    private final String paymentServiceUrl = "http://localhost:9092/payments"; // Update with actual Payment service URL

    public PaymentResponse getPaymentDetails(Long paymentId) {
        String url = paymentServiceUrl + "/" + paymentId;
        return restTemplate.getForObject(url, PaymentResponse.class);
    }
}
