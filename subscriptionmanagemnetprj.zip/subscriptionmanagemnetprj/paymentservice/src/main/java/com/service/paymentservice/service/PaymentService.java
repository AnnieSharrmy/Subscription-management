package com.service.paymentservice.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.service.paymentservice.entity.Payment;
import com.service.paymentservice.repository.PaymentRepository;

import java.time.LocalDateTime;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public Payment processPayment(Long orderId) {
        // Simulate payment processing
        Payment payment = new Payment();
        payment.setOrderId(orderId);
        // payment.setAmount(amount);
        payment.setStatus("SUCCESS");
        payment.setPaymentDate(LocalDateTime.now());

        // Save payment record to the database
        return paymentRepository.save(payment);
    }

    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id).orElse(null);
    }
}