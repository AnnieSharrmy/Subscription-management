package com.airtel.customer.repository;

public interface CustomerRepository  {
         
}
