package com.service.orderservice.entity;

public class OrderRequest {
    private Long userId;
    private String plan;
    private String startDate;
    private String endDate;
    private Double amount; // Ensure this field exists

    // Getters and Setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Double getAmount() {
        return amount; // Ensure this method is properly implemented
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
