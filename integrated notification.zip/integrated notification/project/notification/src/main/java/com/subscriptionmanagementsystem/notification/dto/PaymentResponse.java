package com.subscriptionmanagementsystem.notification.dto;

public class PaymentResponse {
    private Long id;
    private String email;

    // Constructors, getters, and setters
    public PaymentResponse() {
    }

    public PaymentResponse(Long id, String email) {
        this.id = id;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
