package com.verizon.usermanagement.service;
import org.springframework.stereotype.Service;

import com.verizon.usermanagement.entity.Users;
import com.verizon.usermanagement.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Users registerUser(Users user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("Email already in use.");
        }
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            throw new RuntimeException("Username already in use.");
        }
        user.setCreatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }

    public Optional<Users> loginUser(String email, String passwordHash) {
        return userRepository.findByEmail(email)
                .filter(user -> user.getPasswordHash().equals(passwordHash));
    }

    public Optional<Users> getUserById(Long id) {
        return userRepository.findById(id);
    }
}