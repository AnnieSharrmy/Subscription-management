package com.subscriptionmanagementsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendEmail(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        try {
            javaMailSender.send(message);
        } catch (Exception e) {
            // Log or handle email sending failure
            e.printStackTrace();
        }
    }

    public void notifyUserRegistration(String email) {
        sendEmail(email, "User Registration", "You have successfully registered.");
    }

    public void notifyUserLogin(String email) {
        sendEmail(email, "User Login", "You have successfully logged in.");
    }

    public void notifyUserDeletion(String email) {
        sendEmail(email, "User Deletion", "Your account has been deleted.");
    }

    public void notifyPaymentSuccess(String email) {
        sendEmail(email, "Payment Success", "Your payment was successful.");
    }

    public void notifyPaymentFailure(String email) {
        sendEmail(email, "Payment Failure", "Your payment failed. Please try again.");
    }
}
