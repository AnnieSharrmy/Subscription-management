package com.example.sms.controller;

import com.example.sms.entity.Payment;
import com.example.sms.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/add")
    public ResponseEntity<Payment> addPayment(@RequestBody Map<String, Object> paymentDetails) {
        try {
            Long orderId = Long.valueOf(paymentDetails.get("orderId").toString());
            Long userId = Long.valueOf(paymentDetails.get("userId").toString());
            Long amount = Long.valueOf(paymentDetails.get("amount").toString());
            String paymentMethod = paymentDetails.get("paymentMethod").toString();
            String status = paymentDetails.get("status").toString();

            Payment payment = paymentService.addPayment(orderId, userId, amount, paymentMethod, status);
            return new ResponseEntity<>(payment, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/delete/{paymentId}")
    public ResponseEntity<Void> deletePayment(@PathVariable Long paymentId) {
        try {
            paymentService.deletePayment(paymentId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}

