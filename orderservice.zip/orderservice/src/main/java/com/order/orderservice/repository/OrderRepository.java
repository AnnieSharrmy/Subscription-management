package com.order.orderservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.orderservice.model.Order_Table;

//import jakarta.persistence.criteria.Order;

public interface OrderRepository extends JpaRepository<Order_Table, Long> {

    Order_Table save(Order_Table order);
}
