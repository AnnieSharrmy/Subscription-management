package com.verizon.usermanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.usermanagement.entity.Order_Table;
import com.verizon.usermanagement.repository.OrderRepository;

@Service
public class OrderService {
    
    @Autowired
    private OrderRepository orderRepository;

    public Order_Table createOrder(Order_Table order) {
        return orderRepository.save(order);
    }

    public Order_Table updateOrder(Long orderId, Order_Table orderDetails) {
        Optional<Order_Table> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isPresent()) {
            Order_Table order = optionalOrder.get();
            order.setUserId(orderDetails.getUserId());
            order.setPlan(orderDetails.getPlan());
            order.setStartDate(orderDetails.getStartDate());
            order.setEndDate(orderDetails.getEndDate());
            order.setActive(orderDetails.getActive());
            return orderRepository.save(order);
        }
        return null; // or throw an exception
    }

    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
    }

    public Order_Table getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }

    public List<Order_Table> getAllOrders() {
        return orderRepository.findAll();
    }

    public List<Order_Table> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public List<Order_Table> getActiveOrders(Boolean active) {
        return orderRepository.findByActive(active);
    }
    
}
