package com.subscriptionmanagementsystem.notification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.subscriptionmanagementsystem.notification.service.EmailService;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/payment/success")
    public void notifyPaymentSuccess(@RequestParam Long paymentId) {
        emailService.notifyPaymentSuccess(paymentId);
    }

    @PostMapping("/payment/failure")
    public void notifyPaymentFailure(@RequestParam Long paymentId) {
        emailService.notifyPaymentFailure(paymentId);
    }
}
