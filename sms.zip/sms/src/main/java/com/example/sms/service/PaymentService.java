package com.example.sms.service;

import com.example.sms.entity.Payment;
import com.example.sms.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    // Add a new payment
    public Payment addPayment(Long orderId, Long userId, Long amount, String paymentMethod, String status) {
        Payment payment = new Payment(
                orderId,
                userId,
                amount,
                paymentMethod,
                status,
                LocalDateTime.now(),
                LocalDateTime.now()
        );
        return paymentRepository.save(payment);
    }

    // Delete a payment by ID
    public void deletePayment(Long paymentId) {
        paymentRepository.deleteById(paymentId);
    }

    // Optionally, you might want to have methods to find and update payments
    // For example, to find a payment by ID:
    public Payment getPaymentById(Long paymentId) {
        return paymentRepository.findById(paymentId).orElse(null);
    }
}
