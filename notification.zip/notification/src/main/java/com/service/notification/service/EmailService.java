package com.service.notification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.service.notification.client.PaymentClient;
import com.service.notification.client.UsersClient;
import com.service.notification.entity.Notification;
import com.service.notification.repository.NotificationRepository;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UsersClient usersClient;

    @Autowired
    private PaymentClient paymentsClient;

    public void sendEmail(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        try {
            javaMailSender.send(message);

            // Save the notification
            Notification notification = new Notification(to, subject, text);
            notificationRepository.save(notification);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void notifyUserRegistration(Long userId) {
        String email = usersClient.getEmailById(userId);
        sendEmail(email, "User Registration", "You have successfully registered.");
    }

    public void notifyUserLogin(Long userId) {
        String email = usersClient.getEmailById(userId);
        sendEmail(email, "User Login", "You have successfully logged in.");
    }

    public void notifyUserDeletion(Long userId) {
        String email = usersClient.getEmailById(userId);
        sendEmail(email, "User Deletion", "Your account has been deleted.");
    }

    public void notifyPaymentSuccess(Long paymentId) {
        String email = paymentsClient.getPaymentEmailById(paymentId);
        sendEmail(email, "Payment Success", "Your payment was successful.");
    }

    public void notifyPaymentFailure(Long paymentId) {
        String email = paymentsClient.getPaymentEmailById(paymentId);
        sendEmail(email, "Payment Failure", "Your payment failed. Please try again.");
    }
}
