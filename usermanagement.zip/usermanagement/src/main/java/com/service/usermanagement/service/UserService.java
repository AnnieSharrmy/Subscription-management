package com.service.usermanagement.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.service.usermanagement.entity.Users;
import com.service.usermanagement.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public Users registerUser(Users user) {
        user.setCreatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }

    public Users loginUser(String email, String passwordHash) {
        Users user = userRepository.findByEmail(email);
        if (user != null && user.getPasswordHash().equals(passwordHash)) {
            return user;
        } else {
            return null; // Return null if credentials are invalid
        }
    }
}