package com.service.usermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.service.usermanagement.entity.Users;
import com.service.usermanagement.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

  @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody Users user) {
        Users registeredUser = userService.registerUser(user);
        if (registeredUser != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Registration successful for user: " + registeredUser.getUsername());
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed. Please try again.");
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody Users user) {
        Users loggedInUser = userService.loginUser(user.getEmail(), user.getPasswordHash());
        if (loggedInUser != null) {
            return ResponseEntity.ok("Login successful! Welcome " + loggedInUser.getUsername());
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Login failed. Invalid email or password.");
        }
    }
}