package com.service.notification.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "payments-service")  // The name of the Payments microservice
public interface PaymentClient {

    @GetMapping("/api/payments/{paymentId}/email")
    String getPaymentEmailById(@PathVariable("paymentId") Long paymentId);
}

