package com.example;

public class Student {
    int studentId=2;
    String studentName="Prabhu";
    public void display(){
        System.out.println(studentId+" "+studentName);
        
    }

}
