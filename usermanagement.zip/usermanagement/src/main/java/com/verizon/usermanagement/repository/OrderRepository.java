package com.verizon.usermanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.verizon.usermanagement.entity.Order_Table;
@Repository
public interface OrderRepository extends JpaRepository<Order_Table, Long> {
    List<Order_Table> findByUserId(Long userId);
    List<Order_Table> findByActive(Boolean active);
}

