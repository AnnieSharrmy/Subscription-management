package com.service.orderservice.controller;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import com.service.orderservice.entity.OrderRequest;
import com.service.orderservice.service.OrderService;


@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<String> createOrder(@RequestBody OrderRequest orderRequest) {
        boolean isOrderCreated = orderService.createOrder(orderRequest);
        if (isOrderCreated) {
            return ResponseEntity.ok("Order created successfully and forwarded to payment service.");
        } else {
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                                 .body("Failed to create order. Please try again.");
        }
    }
}