package com.service.orderservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.service.orderservice.entity.Orders;

public interface OrderRepository extends JpaRepository<Orders, Long> {

    // Custom query to find an order by userId
    Optional<Orders> findByUserId(Long userId);

    // Custom query to find orders by plan
    List<Orders> findByPlan(String plan);

    // Custom query to find active orders
    List<Orders> findByActive(Boolean active);

    // You can add other custom methods if needed
}
