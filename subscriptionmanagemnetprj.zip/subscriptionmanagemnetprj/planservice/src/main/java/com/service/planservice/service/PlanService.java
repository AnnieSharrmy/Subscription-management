package com.service.planservice.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.service.planservice.entity.Plan;
import com.service.planservice.repository.PlanRepository;
import java.util.Optional;

import java.util.List;

@Service
public class PlanService {

    @Autowired
    private PlanRepository planRepository;
    public Plan getPlanById(Long id) {
        Optional<Plan> plan = planRepository.findById(id);
        return plan.orElse(null);
    }

    public List<Plan> getPlansByCost(Double price) {
        return planRepository.findByPrice(price);
    }

    public List<Plan> getAllPlans() {
        return planRepository.findAll();
    }
}