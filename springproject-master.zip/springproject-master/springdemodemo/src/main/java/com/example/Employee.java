package com.example;

public class Employee {
    int employeeId=200;
    String employeeName="verizon";
    public void display(){
        System.out.println(employeeId+" "+employeeName);
        
    }

}
